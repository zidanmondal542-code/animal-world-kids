Animal World Kids - Android Studio project

This is the Android app source project. It wraps the offline kids game in an Android WebView.

To build an APK:
1. Install Android Studio on a computer.
2. Open this AnimalWorldAndroid folder in Android Studio.
3. Allow Gradle sync and install the requested Android SDK (API 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).

The APK will be created under app/build/outputs/apk/debug/.

The game itself is offline and does not request internet permission. Bengali voice depends on the phone's installed text-to-speech Bengali voice; the visual game works without it.
